import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Menu {
    // los componentes del gui para interactuar con ellos
    private JButton revisarButton;
    private JButton agregarButton;
    private JButton buscarButton;
    private JButton eliminarButton;
    // se coloca en publico las variables que necesitemos llamar a todo el codigo
    public JPanel ventana;

    public Menu() {
        //Creacion de una accion al aplastar el boton o casilla especifica
        revisarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Llamado de la otra ventana para actuar como  un menu
                JFrame observar = new JFrame("Registro");
                observar.setContentPane(new Vista().sorevisa);
                observar.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                observar.setSize(500,200);
                observar.setPreferredSize(new Dimension(500,200));
                observar.setVisible(true);
            }
        });
    }
}
