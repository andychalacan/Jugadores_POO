import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Login {
    private JTextField name;
    private JTextField contra;
    private JButton ingresar;
    public JPanel panel1;



    public Login() {

        ingresar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //Creacion de variables temporales para identificar si funciona el login correctamente
                String nombre="Andy";
                int contraa=1234;
                        //Creacion de una condicional para adecuarse a un login funcional
                if (nombre.equals(String.valueOf(name.getText() )) && contraa==Integer.parseInt(contra.getText())){
                    System.out.println("Funca");
                    //Llamada del menu si el login es valido
                    JFrame menu = new JFrame("Menu");
                    menu.setContentPane(new Menu().ventana);
                    menu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    menu.setSize(500,200);
                    menu.setPreferredSize(new Dimension(500,200));
                    menu.setVisible(true);
                } else{
                    //Ventana emergente indicando error en el ingreso
                    System.out.println("no funca");
                    JOptionPane.showMessageDialog(null, "ERROR / USUARIO o CONTRASEÑA INCORRECTA");
                }
                
            }
        });
    }
}
