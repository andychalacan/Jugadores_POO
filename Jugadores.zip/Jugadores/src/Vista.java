import javax.swing.*;
// Main de la ventana de registro
public class Vista {
    public JPanel sorevisa;
    private JTable table1;
}
