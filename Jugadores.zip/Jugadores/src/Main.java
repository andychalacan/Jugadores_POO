import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        //Aqui son las variables para iniciar la interfaz grafica permitiendo editar los valores de pantalla, titulo entre otros.
        JFrame frame = new JFrame("Ingreso");
        frame.setContentPane(new Login().panel1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,200);
        frame.setPreferredSize(new Dimension(500,200));
        frame.pack();
        frame.setVisible(true);
    }
}